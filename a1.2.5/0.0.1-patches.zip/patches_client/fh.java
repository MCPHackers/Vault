
public class fh {
    public static int b(double d)
    {
        int i = (int)d;
        return d >= (double)i ? i : i - 1;
    }
}
